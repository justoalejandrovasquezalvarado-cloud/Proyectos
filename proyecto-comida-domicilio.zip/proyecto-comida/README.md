# Sabor Directo — Sistema de Pedidos de Comida a Domicilio

Proyecto integral Full Stack: **HTML5, CSS3, JavaScript Vanilla, Node.js, Express y MySQL**,
desarrollado según la especificación técnica del curso (5 fases / 20 puntos).

## Estructura del proyecto

```
proyecto-comida/
├── backend/
│   ├── server.js          # Servidor Express + sirve el frontend
│   ├── db.js               # Conexión a MySQL (pool con mysql2/promise)
│   ├── schema.sql           # Script de creación de la BD pedidos_db + datos de prueba
│   ├── package.json
│   ├── .env.example         # Plantilla de variables de entorno
│   └── routes/
│       ├── productos.js     # GET /api/productos
│       └── pedidos.js       # POST /api/pedidos , GET /api/pedidos/:id
└── frontend/
    ├── index.html            # Catálogo, carrito y checkout (una sola página)
    ├── css/style.css
    └── js/
        ├── api.js            # Peticiones fetch a la API
        ├── cart.js           # Lógica del carrito + localStorage
        └── app.js            # Renderizado e interacción de la UI
```

## Requisitos previos

- Node.js 18 o superior
- MySQL (por ejemplo, vía XAMPP) corriendo en `localhost:3306`

## 1. Crear la base de datos

Abre tu cliente de MySQL (phpMyAdmin, MySQL Workbench o la terminal) y ejecuta el script:

```bash
mysql -u root -p < backend/schema.sql
```

Esto crea la base de datos `pedidos_db`, las 4 tablas (`usuarios`, `productos`, `pedidos`,
`detalles_pedido`) y precarga un catálogo de productos de ejemplo.

## 2. Configurar variables de entorno

Dentro de `backend/`, copia el archivo de ejemplo y ajusta tus credenciales:

```bash
cd backend
cp .env.example .env
```

Edita `.env` con tu usuario/contraseña de MySQL (por defecto XAMPP usa `root` sin contraseña).

## 3. Instalar dependencias

```bash
npm install
```

## 4. Levantar el servidor

```bash
npm start
```

Verás en consola: `Servidor corriendo en http://localhost:3000`

## 5. Usar la aplicación

Abre tu navegador en **http://localhost:3000** — el propio servidor Express sirve el
frontend, así que no necesitas abrir el `index.html` por separado ni configurar CORS
para uso local (aunque el middleware CORS ya está habilitado por si prefieres servir el
frontend desde otro puerto, por ejemplo con Live Server).

## Endpoints de la API REST

| Método | Ruta                | Descripción                                            |
|--------|---------------------|---------------------------------------------------------|
| GET    | `/api/productos`    | Devuelve el catálogo completo de productos               |
| POST   | `/api/pedidos`      | Crea un pedido (usuario, items del carrito y total)       |
| GET    | `/api/pedidos/:id`  | Consulta el estado y resumen de un pedido específico       |

## Flujo funcional

1. El catálogo se carga dinámicamente desde MySQL vía `GET /api/productos`.
2. El usuario agrega productos al carrito; el carrito persiste en `localStorage`
   (sobrevive a recargas de página).
3. Al hacer clic en "Continuar al pago" se valida el carrito y se abre el formulario de
   entrega con validaciones en tiempo real (nombre, correo, teléfono, dirección).
4. Al confirmar, el frontend envía el pedido vía `POST /api/pedidos` (fetch + async/await,
   sin recargar la página).
5. El backend crea/actualiza el usuario, inserta el pedido y sus detalles dentro de una
   transacción MySQL, y responde con el número de orden.
6. Se muestra la pantalla de confirmación con número de pedido, tiempo estimado de entrega
   y resumen tipo recibo.

## Notas de diseño

- CSS propio, sin frameworks (Bootstrap/Tailwind), completamente responsive.
- Interfaz dividida por categorías filtrables (Hamburguesas, Pizzas, Tacos, Ensaladas,
  Acompañamientos, Bebidas, Postres).
- Base de datos relacional normalizada con llaves foráneas y estados de pedido
  (`pendiente`, `en_preparacion`, `entregado`).
